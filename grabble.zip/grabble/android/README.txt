Notes for Part 3

- Professor said to remove the vibration as it is an intrusion since there are so many markers
	---- SPECIFY that you said that you will make it vibrate in the Design Document but after
	     the feedback from Part 1 you changed your mind

- Changed the Music Service class to a simpler implementation only in the MapActivity since it was buggy.

- After feedback from Part 1 --> 
			     
Suggestions from FEEDBACK
- I will not ask user for calendar since you go into its personal information but instead i take server time as suggested in feedback.
- Decided to completely remove the marker instead of changing its color.
- Remove the vibration as it is an intrusion since there are so many markers
- Explain about the distance of user location from placemarks and how they will get the letter
--- You didnt provide a detailed explanation of - How does a user form a word
					        - How do you validate a word
- User can only make a word once. NO duplicates allowed



Improvements
- Make the word disappear after its creation --------------------
- History --> make words appear in descending order --> highest-value word first --------------
- Make the toast on letters show only when you have 0 letters left ------------------
- Put an image in history layout to indicate Highscores ---------
- Set all markers invisible and make them visible when they are in range?? 10m ----------------
- Set dictionary available only at 500pts and you deduct 500pts from the user every time he uses it, he can only access it on the spot
- Sign up page changes to forgot password after signing up for the game--------

